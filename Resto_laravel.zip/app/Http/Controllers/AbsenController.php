<?php

namespace App\Http\Controllers;

use App\Models\Absen;
use App\Models\Karyawan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AbsenController extends Controller
{
    public function index(Request $request)
    {
        $id_user = Auth::user()->id;
        $id_menu = DB::table('tb_permission')->select('id_menu')->where('id_user',$id_user)
        ->where('id_menu', 2)->first();
        if(empty($id_menu)) {
            return back();
        } else {
            $data = [
                'title' => 'Absen',
                'logout' => $request->session()->get('logout'),
                'karyawan' => Karyawan::paginate(10),
            ];

            return view('absen.absen', $data);
        }
    }

    public function addAbsen(Request $request)
    {
       $data = [
        'id_karyawan' => $request->id_karyawan,
        'status' => 'M',
        'tgl' => $request->tanggal,
        'id_lokasi' => $request->session()->get('id_lokasi'),
        'page' => $request->page,
       ];
    //    dd($data['page']);
       Absen::create($data);
       return redirect()->route('absen', ['page' => $request->page, 'bulan' => $request->bulan, 'tahun' => $request->tahun]);

    }

    public function updateAbsen(Request $request)
    {
        $data = [
            'status' => $request->status,
        ];

        Absen::where('id_absen',$request->id_absen)->update($data);
        return true;
    }

    public function deleteAbsen(Request $request)
    {
        Absen::where('id_absen',$request->id_absen)->delete();
        return true;

    }


}
