<div class="row">
    <div class="col-12">
        <div class="card mt-5">
            <div class="card-header">
                <?php echo e($dari); ?> sampai <?php echo e($sampai); ?>


                <a href="<?php echo e(route('gajiSum', ['dari' => $dari, 'sampai' => $sampai])); ?>"
                    class="btn mr-2 btn-info btn-sm float-right"><i class="fas fa-file-export"></i>
                    Export</a>
            </div>

            <div class="card-body">
                <table class="table table-responsive" id="tableSum">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>NAMA KARYAWAN</th>
                            <th>TANGGAL MASUK</th>
                            <th>RP M</th>
                            <th>RP E</th>
                            <th>RP SP</th>
                            <th>BULANAN</th>
                            <th>TOTAL</th>
                            <th>POINT MASAK</th>
                            <th>NON POINT MASAK</th>
                            <th>CUCI/JAM</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($k->nama); ?></td>
                                <td><?php echo e($k->tgl_masuk); ?></td>
                                <td><?php echo e(number_format($k->rp_m * $k->M)); ?></td>
                                <td><?php echo e(number_format($k->rp_e * $k->E)); ?></td>
                                <td><?php echo e(number_format($k->rp_sp * $k->Sp)); ?></td>
                                <td><?php echo e($k->g_bulanan); ?></td>
                                <td><?php echo e(number_format($k->rp_m * $k->M + $k->rp_e * $k->E + $k->rp_sp * $k->Sp)); ?>

                                </td>
                                <td><?= $k->point_berhasil ? $k->point_berhasil : 0 ?></td>
                                <td><?= $k->point_gagal ? $k->point_gagal : 0 ?></td>
                                <td><?php echo e(number_format($k->lama_cuci ? $k->lama_cuci / 60 : 0, 1)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/gaji/tabelGaji.blade.php ENDPATH**/ ?>