<div class="subnavbar">
    <div class="subnavbar-inner">
        <div class="container">
            <ul class="mainnav">
                <li>
                    <a href="admin/beranda">
                        <img src="an-component/icon/dashboard.png"><span>Beranda</span>
                    </a>
                </li>
                <li><a href="Jurnal"><img src="an-component/icon/budget.png"><span>Accounting</span> </a> </li>
                <li><a href="admin/report"><img src="an-component/icon/barchart.png"><span>Report TS</span> </a> </li>
                <!--<li><a href="admin/jurnal"><img src="an-component/icon/clipboard.png"><span>Jurnal TS</span> </a> </li>-->
                <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <img
                            src="an-component/icon/piechart.png"><span>Laporan</span> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="admin/laporan/bulanan">Bulanan</a></li>
                        <li><a href="admin/laporan/harian">Harian</a></li>
                        <li><a href="admin/laporan/nota">Per-Nota</a></li>
                    </ul>
                </li>
                <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <img
                            src="an-component/icon/frames.png"><span>Tabel</span> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="admin/tabel/bumbu">TB Bumbu</a></li>
                        <li><a href="admin/tabel/cost">TB Cost Control</a></li>
                        <li><a href="admin/tabel/karyawan">TB Karyawan TS</a></li>
                        <li><a href="admin/tabel/menu">TB Menu Resto</a></li>
                        <li><a href="admin/tabel/omset">TB Omset</a></li>
                        <li><a href="admin/tabel/gaji">TB Rekap Gaji TS</a></li>
                        <li><a href="admin/tabel/user">TB User</a></li>
                    </ul>
                </li>
                <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <img
                            src="an-component/icon/colorwheel.png"><span>Lain-Lain</span> <b
                            class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="Karyawan">Daftar Karyawan</a></li>
                        <li><a href="admin/more/absen">Report Absen</a></li>
                        <li><a href="admin/more/cuci">Report Cuci</a></li>
                        <li><a href="admin/more/denda">Report Denda</a></li>
                        <li><a href="admin/more/kasbon">Report Kasbon</a></li>
                        <li><a type="button" data-toggle="modal" data-target="#modalkoki">Report Masak</a></li>
                        <li><a href="admin/more/driver">Report Driver</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <!-- /container -->
    </div>
    <!-- /subnavbar-inner -->
</div>
<?php /**PATH C:\Users\User\Documents\laravel\Resto_laravel\resources\views/template/navbar.blade.php ENDPATH**/ ?>