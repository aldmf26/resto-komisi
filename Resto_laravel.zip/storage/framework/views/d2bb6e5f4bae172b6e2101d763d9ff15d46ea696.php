
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper" style="min-height: 494px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container">
                <div class="row mb-2 justify-content-center">
                    <div class="col-sm-12">
                        <center>
                            <h4 style="color: rgb(120, 120, 120); font-weight: bold; --darkreader-inline-color:#837e75;"
                                data-darkreader-inline-color="">Orderan</h4>
                        </center>

                    </div><!-- /.col -->

                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <a class="btn btn-info float-right" data-toggle="modal" data-target="#view"><i
                                class="fas fa-eye"></i> View</a>
                        <br>
                        <br>
                        <div class="card">
                            <div class="card-body">
                                <div id="table_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table class="table dataTable no-footer" id="table" width="100%"
                                                style="font-size: 12px; width: 100%;" role="grid"
                                                aria-describedby="table_info">
                                                <thead>
                                                    <tr role="row">
                                                        <th style="font-size: 12px; width: 18px;"
                                                            class="sorting sorting_asc" tabindex="0" aria-controls="table"
                                                            rowspan="1" colspan="1" aria-sort="ascending"
                                                            aria-label="No: activate to sort column descending">No</th>
                                                        <th style="font-size: 12px; width: 44px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="No Order: activate to sort column ascending">No
                                                            Order</th>
                                                        <th style="font-size: 12px; width: 40px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Table: activate to sort column ascending">Table</th>
                                                        <th style="font-size: 12px; width: 35px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Menu: activate to sort column ascending">Menu</th>
                                                        <th style="font-size: 12px; width: 25px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Qty: activate to sort column ascending">Qty</th>
                                                        <th style="font-size: 12px; width: 44px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Harga: activate to sort column ascending">Harga</th>
                                                        <th style="font-size: 12px; width: 43px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Time Order: activate to sort column ascending">Time
                                                            Order</th>
                                                        <th style="font-size: 12px; width: 50px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Server: activate to sort column ascending">Server
                                                        </th>
                                                        <th style="font-size: 12px; width: 30px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Koki: activate to sort column ascending">Koki</th>
                                                        <th style="font-size: 12px; width: 63px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Waitress: activate to sort column ascending">
                                                            Waitress</th>
                                                        <th style="font-size: 12px; width: 40px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Time Delay: activate to sort column ascending">Time
                                                            Delay</th>
                                                        <th style="font-size: 12px; width: 47px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Status: activate to sort column ascending">Status
                                                        </th>
                                                        <th style="font-size: 12px; width: 29px;" class="sorting"
                                                            tabindex="0" aria-controls="table" rowspan="1" colspan="1"
                                                            aria-label="Aksi: activate to sort column ascending">Aksi</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr class="odd">
                                                        <td valign="top" colspan="13" class="dataTables_empty">No data
                                                            available in table</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <form action="https://upperclassindonesia.com/Order/order1" method="get">
                        <div class="modal fade" id="view">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header bg-info">
                                        <h4 class="modal-title">View</h4>
                                        <button type="button" class="close" data-dismiss="modal"
                                            aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">

                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-lg-6">
                                                    <label for="">Dari</label>
                                                    <input type="date" name="tgl" class="form-control">
                                                </div>
                                                <div class="col-lg-6">
                                                    <label for="">Sampai</label>
                                                    <input type="date" name="tgl2" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer justify-content-between">
                                            <button type="button" class="btn btn-default"
                                                data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary" target="_blank">Lanjutkan</button>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/orderan/orderan.blade.php ENDPATH**/ ?>