@extends('errors::minimal')
@section('title', __('Server Error'))
@section('message', __('Silahkan Login Dulu'))
