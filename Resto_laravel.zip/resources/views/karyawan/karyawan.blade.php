@extends('template.master')
@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container">
                <div class="row mb-2 justify-content-center">
                    <div class="col-sm-12">

                    </div><!-- /.col -->

                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Data karyawan</h5>
                                <a href="" data-toggle="modal" data-target="#tambah" class="btn btn-info float-right"><i
                                        class="fas fa-plus"></i> Tambah karyawan</a>
                            </div>
                            @include('flash.flash')
                            <div class="card-body">
                                <table class="table  " id="table">

                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>NAMA KARYAWAN</th>
                                            <th>TANGGAL MASUK</th>
                                            <th>STATUS</th>
                                            <th>POSISI</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                            $no = 1;
                                        @endphp
                                        @foreach ($karyawan as $k)
                                            @php
                                                $totalKerja = new DateTime($k->tgl_masuk);
                                                $today = new DateTime();
                                                $tKerja = $today->diff($totalKerja);
                                            @endphp
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ $k->nama }}</td>
                                                <td>{{ $k->tgl_masuk }} ({{ $tKerja->y }} Tahun)</td>
                                                <td>{{ $k->nm_status }}</td>
                                                <td>{{ $k->nm_posisi }}</td>
                                                <td style="white-space: nowrap;">
                                                    <a href="" data-toggle="modal"
                                                        data-target="#edit_data{{ $k->id_karyawan }}" id_menu="1"
                                                        class="btn edit_menu btn-new" style="background-color: #F7F7F7;"><i
                                                            style="color: #B0BEC5;"><i class="fas fa-edit"></i></a>
                                                    <a onclick="return confirm('Apakah ingin dihapus ?')"
                                                        href="{{ route('deleteKaryawan', ['id_karyawan' => $k->id_karyawan]) }}"
                                                        class="btn  btn-new" style="background-color: #ff0000;">
                                                        <i style="color: #B0BEC5;"><i class="fas fa-trash-alt"></i></a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>

                                </table>
                            </div>
                        </div>

                    </div>







                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <style>
        .modal-lg-max {
            max-width: 900px;
        }

    </style>
    <form action="{{ route('addKaryawan') }}" method="post" accept-charset="utf-8">
        @csrf
        <div class="modal fade" id="tambah" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg-max" role="document">
                <div class="modal-content ">
                    <div class="modal-header btn-costume">
                        <h5 class="modal-title text-light" id="exampleModalLabel">Tambah karyawan</h5>
                        <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-3">
                                <label for="">Tgl Masuk</label>
                                <input type="date" name="tgl_masuk" class="form-control">
                            </div>
                            <div class="col-lg-3">
                                <label for="">Nama</label>
                                <input type="text" name="nama" class="form-control">
                            </div>
                            <div class="col-lg-3">
                                <label for="">Status</label>
                                <select name="status" id="" class="form-control">
                                    <option value="">- Pilih Status - </option>
                                    @foreach ($status as $s)
                                        <option value="{{ $s->id_status }}">{{ $s->nm_status }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-3">
                                <label for="">Posisi</label>
                                <select name="posisi" id="" class="form-control">
                                    <option value="">- Pilih Posisi - </option>
                                    @foreach ($posisi as $p)
                                        <?php if($p->id_posisi == 1){ ?>
                                        <?php continue; ?>
                                        <?php } ?>
                                        <option value="{{ $p->id_posisi }}">{{ $p->nm_posisi }}</option>
                                    @endforeach
                                </select>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">

                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    {{-- modal untuk edit --}}
    @foreach ($karyawan as $k)
        <form action="{{ route('editKaryawan') }}" method="post" accept-charset="utf-8">
            @csrf
            @method('patch')
            <div class="modal fade" id="edit_data{{ $k->id_karyawan }}" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg-max" role="document">
                    <div class="modal-content ">
                        <div class="modal-body">
                            <div class="row">
                                <input type="hidden" name="id_karyawan" value="{{ $k->id_karyawan }}">
                                <div class="col-lg-3">
                                    <label for="">Tgl Masuk</label>
                                    <input type="date" value="{{ $k->tgl_masuk }}" name="tgl_masuk"
                                        class="form-control">
                                </div>
                                <div class="col-lg-3">
                                    <label for="">Nama</label>
                                    <input type="text" name="nama" value="{{ $k->nama }}" class="form-control">
                                </div>

                                <div class="col-lg-3">
                                    <label for="">Status</label>
                                    <select name="status" id="" class="form-control">
                                        <option value="">- Pilih Status - </option>
                                        @foreach ($status as $s)
                                            <option value="{{ $s->id_status }}"
                                                {{ $s->id_status == $k->id_status ? 'selected' : '' }}>
                                                {{ $s->nm_status }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-lg-3">
                                    <label for="">Posisi</label>
                                    <select name="posisi" id="" class="form-control">
                                        <option value="">- Pilih Posisi - </option>
                                        @foreach ($posisi as $p)
                                            <?php if($p->id_posisi == 1){ ?>
                                            <?php continue; ?>
                                            <?php } ?>
                                            <option value="{{ $p->id_posisi }}"
                                                {{ $p->id_posisi == $k->id_posisi ? 'selected' : '' }}>
                                                {{ $p->nm_posisi }}</option>
                                        @endforeach
                                    </select>
                                </div>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-costume" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-costume">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    @endforeach
    {{-- ---------------- --}}
@endsection
@section('script')
@endsection
