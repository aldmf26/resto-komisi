@include('template.head')
@include('template.header')
@include('template.navbar')


@yield('content')
@include('template.footer')

