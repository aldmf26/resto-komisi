<table border="1" cellpadding="8">
    <tr>
        <th>NO</th>
        <th>TANGGAL</th>
        <th>NAMA</th>
        <th>ALASANA</th>
        <th>NOMINAL</th>
        <th>LOKASI</th>
    </tr>
    @php
        $no = 1;
    @endphp
    @foreach ($denda as $k)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $k->tgl }}</td>
            <td>{{ $k->nama }}</td>
            <td>{{ $k->alasan }}</td>
            <td>{{ $k->nominal }}</td>
            @php
                if ($k->id_lokasi == 1) {
                    $lokasi = 'TAKEMORI';
                } else {
                    $lokasi = 'SOONDOBU';
                }
            @endphp
            <td>{{ $lokasi }}</td>
        </tr>
    @endforeach
</table>
