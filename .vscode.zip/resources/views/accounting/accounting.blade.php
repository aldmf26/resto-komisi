@extends('template.master')
<h1>Accoutning</h1>
@section('content')
@endsection
