<div class="card-body">
    <div id="table_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
        <div class="row">
            <div class="col-sm-12">
                <table class="table dataTable no-footer" id="table" role="grid" aria-describedby="table_info">
                    <thead>
                        <tr role="row">
                            <th>No
                            </th>
                            <th>Nama Distribusi</th>
                            <th>
                                Service</th>
                            <th>
                                Ongkir</th>
                            <th>Tax
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $distribusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td class="sorting_1"><?php echo e($no++); ?></td>
                                <td><?php echo e($d->nm_distribusi); ?></td>
                                <td>
                                    <?php if($d->service == 'Y'): ?>
                                        <a href="#" value="T" status="service" id_distribusi="<?php echo e($d->id_distribusi); ?>"
                                            class="btnDelete btn btn-primary">
                                            ON
                                        </a>
                                    <?php else: ?>
                                        <a href="#" value="Y" status="service" id_distribusi="<?php echo e($d->id_distribusi); ?>"
                                            class="btnInput btn btn-dark">
                                            OFF
                                        </a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($d->ongkir == 'Y'): ?>
                                        <a href="#" value="T" status="ongkir" id_distribusi="<?php echo e($d->id_distribusi); ?>"
                                            class="btnDelete btn btn-primary">
                                            ON
                                        </a>
                                    <?php else: ?>
                                        <a href="#" value="Y" status="ongkir" id_distribusi="<?php echo e($d->id_distribusi); ?>"
                                            class="btnInput btn btn-dark">
                                            OFF
                                        </a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($d->tax == 'Y'): ?>
                                        <a href="#" value="T" status="tax" id_distribusi="<?php echo e($d->id_distribusi); ?>"
                                            class="btnDelete btn btn-primary">
                                            ON
                                        </a>
                                    <?php else: ?>
                                        <a href="#" value="Y" status="tax" id_distribusi="<?php echo e($d->id_distribusi); ?>"
                                            class="btnInput btn btn-dark">
                                            OFF
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/distribusi/tabelDistribusi.blade.php ENDPATH**/ ?>