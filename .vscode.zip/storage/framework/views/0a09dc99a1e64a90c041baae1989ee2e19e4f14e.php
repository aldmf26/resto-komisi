<?php $__env->startSection('title', __('Server Error')); ?>
<?php $__env->startSection('message', __('Silahkan Login Dulu')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/errors/500.blade.php ENDPATH**/ ?>