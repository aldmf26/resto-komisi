<?php
header('Content-type: application/vnd-ms-excel');
header('Content-Disposition: attachment; filename=Data Gaji.xls');
?>
<div class="row">
    <div class="col-12">
        <div class="card mt-5">
            <center>
                <h2 style="margin-right: 300px">Gaji Karyawan</h2>
            </center>
            <div class="card-header">
                <h3 style="margin-left: 50px">Dari <?php echo e($dari); ?> Sampai <?php echo e($sampai); ?></h3>
            </div>

            <div class="card-body">
                <table border="1">

                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Tgl Masuk</th>
                            <th>Tahun</th>
                            <th>Bulan</th>
                            <th>Posisi</th>
                            <th>Absen M</th>
                            <th>Absen E</th>
                            <th>Absen SP</th>
                            <th>RP M</th>
                            <th>RP E</th>
                            <th>RP SP</th>
                            <th>Bulanan</th>
                            <th>Point Masak</th>
                            <th>Non Point Masak</th>
                            <th>Cuci/jam</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                            $total = 0;
                            $total_gagal = 0;
                            $total_berhasil = 0;
                            $total_cuci = 0;
                        ?>
                        <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                
                                $total += $k->rp_m * $k->M + $k->rp_e * $k->E + $k->rp_sp * $k->Sp + $k->g_bulanan;
                                $total_cuci += $k->lama_cuci ? $k->lama_cuci / 60 : 0;
                                
                            ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($k->nama); ?></td>
                                <td><?php echo e($k->tgl_masuk); ?></td>
                                <?php
                                    $totalKerja = new DateTime($k->tgl_masuk);
                                    $today = new DateTime();
                                    $tKerja = $today->diff($totalKerja);
                                ?>
                                <td><?php echo e($tKerja->y); ?></td>
                                <td><?php echo e($tKerja->m); ?></td>
                                <td><?php echo e($k->nm_posisi); ?></td>
                                <td><?php echo e($k->M); ?></td>
                                <td><?php echo e($k->E); ?></td>
                                <td><?php echo e($k->Sp); ?></td>
                                <td><?php echo e(number_format($k->rp_m)); ?></td>
                                <td><?php echo e(number_format($k->rp_e)); ?></td>
                                <td><?php echo e(number_format($k->rp_sp)); ?></td>
                                <td><?php echo e($k->g_bulanan); ?></td>
                                <td>1</td>
                                <td>1</td>
                                <td><?php echo e(number_format($k->lama_cuci ? $k->lama_cuci / 60 : 0, 1)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th colspan="12" align="center">TOTAL</th>
                            <th><?php echo e(number_format($total)); ?></th>
                            <th><?= number_format($total_berhasil, 1) ?></th>
                            <th><?= number_format($total_gagal, 1) ?></th>
                            <th><?= number_format($total_cuci, 1) ?></th>
                        </tr>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/gaji/excel.blade.php ENDPATH**/ ?>