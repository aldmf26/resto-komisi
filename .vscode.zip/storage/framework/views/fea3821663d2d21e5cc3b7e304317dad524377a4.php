<div class="card-body">
    <div id="table_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">

        <div class="row">
            <div class="col-sm-12">
                <table class="table dataTable no-footer" id="table" role="grid"
                    aria-describedby="table_info">
                    <thead>
                        <tr role="row">
                            <th>No</th>
                            <th>Nama Koki</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $koki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($ko->nama); ?></td>
                                <td>
                                    <a href="javascript:void(0)" id_koki="<?php echo e($ko->id_koki); ?>"
                                        class="hapusKoki btn btn-sm btn-primary">non-aktifkan
                                        koki</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>

    </div>
</div><?php /**PATH /home/u1134130/resto_laravel/resources/views/addKoki/tabelKoki.blade.php ENDPATH**/ ?>