<!-- ======================================================== conten ======================================================= -->
<style>
    #background {
        position: absolute;
        z-index: 0;
        background: white;
        display: block;
        min-height: 50%;
        min-width: 50%;
        color: yellow;
    }

    #content {
        position: absolute;
        z-index: 1;
    }

    #bg-text {
        color: lightgrey;
        font-size: 120px;
        transform: rotate(300deg);
        -webkit-transform: rotate(300deg);
    }
</style>
<div id="background">
    <p id="bg-text">Copy</p>
</div>
<div style="font-size: 14px;" id="content">
    <table align="center" class="table" style="font-size: 14px;">
        <tbody>
            <tr>
                <td>
                    invoice #
                    <?php echo e($no_order); ?><br>
                    Server :
                    Takemori
                </td>
                <td>
                    <?php
                    $Weddingdate = new DateTime($pesan_2->j_mulai);
                    echo $Weddingdate->format("M j, h:i:s a");
                    ?>
                    <br>
                </td>
                <td>
                    <?php echo e($pesan_2->nm_meja); ?>

                </td>
            </tr>
        </tbody>
    </table>
    <hr>
    <table class="table" align="center" style="font-size: 14px;">
        <thead style="font-family: Footlight MT Light;">
            <tr>
                <th>QTY :
                    <?php echo e($pesan_2->sum_qty); ?>

                </th>
                <th>NAMA MENU :
                    <?php echo e($pesan_2->sum_qty); ?>

                </th>
                <th>Time: </th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($order  as $d) : ?>
            <tr>
                <td align="center">
                    <?php echo e($d->qty); ?>

                </td>
                <td>
                    <?php echo e($d->nm_menu); ?> <br> ***
                    <?php echo e($d->request); ?>

                </td>
                <td>
                    <?php echo e(date('h:i a', strtotime($d->j_mulai))); ?>

                </td>
            </tr>
            <tr>
                <td colspan="2"></td>
            </tr>
            <?php endforeach ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3"></td>
            </tr>
        </tfoot>
    </table>
    <hr>
    <input type="hidden" id="kode" value="<?php echo e($no_order); ?>">

</div>
<!-- ======================================================== conten ======================================================= -->
<script>
    window.print();
</script><?php /**PATH /home/u1134130/resto_laravel/resources/views/meja/copy_checker.blade.php ENDPATH**/ ?>