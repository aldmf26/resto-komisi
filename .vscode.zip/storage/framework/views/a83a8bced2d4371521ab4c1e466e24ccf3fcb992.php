<div class="row">
    <?php $__currentLoopData = $menu2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <a href="" class="input_cart2" data-toggle="modal" data-target="#myModal" id_harga="<?php echo e($t->id_harga); ?>"
                id_dis="<?php echo e($id_dis); ?>">
                <div class="card">
                    <div style="background-color: rgba(0, 0, 0, 0.5); padding:5px 0 5px;">
                        <h6 style="font-weight: bold; color:#fff;" class="text-center">
                            <?php echo e(ucwords(Str::lower($t->nm_menu))); ?>


                        </h6>
                    </div>
                    <div class="card-body" style="padding:0.2rem;">
                        <p class="mt-2 text-center demoname" style="font-size:15px; color: #787878;"><strong>Rp.
                                <?php echo e(number_format($t->harga)); ?></strong></p>
                    </div>
                </div>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/u1134130/resto_laravel/resources/views/order/search.blade.php ENDPATH**/ ?>