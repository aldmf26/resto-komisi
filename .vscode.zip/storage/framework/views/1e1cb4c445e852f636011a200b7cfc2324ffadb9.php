
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper" style="min-height: 494px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container">
                <div class="row mb-2 justify-content-center">
                    <div class="col-lg-12">



                    </div>

                </div>
            </div>
        </div>

        <div class="content">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="float-left">Data Denda</h5>
                                <a href="" data-toggle="modal" data-target="#tambah"
                                    class="btn btn-info btn-sm float-right"><i class="fas fa-plus"></i> Tambah Data</a>
                                <a href="<?php echo e(route('printDenda')); ?>" class="btn btn-info btn-sm float-right mr-2"><i
                                        class="fas fa-print"></i>Print</a>
                            </div>
                            <div class="card-body">
                                <div id="table_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <table class="table dataTable no-footer" id="table" role="grid"
                                                aria-describedby="table_info">
                                                <thead>
                                                    <tr role="row">
                                                        <th>No</th>
                                                        <th>Tanggal</th>
                                                        <th>Nama</th>
                                                        <th>Alasan</th>
                                                        <th>Nominal</th>
                                                        <th>Lokasi</th>
                                                        <th>Admin</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <?php
                                                        $no = 1;
                                                    ?>
                                                    <?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            if ($d->id_lokasi == 1) {
                                                                $lokasi = 'TAKEMORI';
                                                            } else {
                                                                $lokasi = 'SOONDOBU';
                                                            }
                                                        ?>
                                                        <tr class="odd">
                                                            <td><?php echo e($no++); ?></td>
                                                            <td width="100"><?php echo e($d->tgl); ?></td>
                                                            <td><?php echo e(ucwords(Str::lower($d->nama))); ?></td>
                                                            <td width="300"><?php echo e($d->alasan); ?></td>
                                                            <td width="100">Rp.
                                                                <?php echo e(number_format($d->nominal, 0, '.', '.')); ?></td>
                                                            <td><?php echo e($lokasi); ?></td>

                                                            <td><?php echo e(ucwords(Str::lower($d->admin))); ?></td>
                                                            <td width="100">
                                                                <a data-target="#edit_data<?php echo e($d->id_denda); ?>"
                                                                    data-toggle="modal" class="btn btn-info btn-sm"><i
                                                                        class="fas fa-edit"></i></a>
                                                                <a href="<?php echo e(route('deleteDenda', ['id_denda' => $d->id_denda])); ?>"
                                                                    onclick="return confirm('Apakah anda yakin?')"
                                                                    class="btn btn-danger btn-sm"><i
                                                                        class="fas fa-trash"></i></a>
                                                            </td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>


                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
    <form action="<?php echo e(route('addDenda')); ?>" method="post" accept-charset="utf-8">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="tambah" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg-max" role="document">
                <div class="modal-content ">
                    <div class="modal-header btn-costume">
                        <h5 class="modal-title text-light" id="exampleModalLabel">Tambah Denda</h5>
                        <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">

                            <div class="col-6">
                                <div class="form-group">
                                    <label for="list_kategori">Tanggal</label>
                                    <input class="form-control" type="date" name="tgl">
                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <label for="list_kategori">Nama</label>
                                    <select class="form-control" name="nama" id="">
                                        <option>-- Pilih Nama --</option>
                                        <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($k->nama); ?>"><?php echo e($k->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <label for="list_kategori">Alasan</label>
                                    <input class="form-control" type="text" name="alasan">
                                </div>
                            </div>

                            <div class="col-6">
                                <div class="form-group">
                                    <label for="list_kategori">Nominal</label>
                                    <input class="form-control" type="number" name="nominal">
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">

                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    
    <?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('editDenda')); ?>" method="post" accept-charset="utf-8">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="modal fade" id="edit_data<?php echo e($k->id_denda); ?>" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg-max" role="document">
                    <div class="modal-content ">
                        <div class="modal-body">
                            <div class="row">
                                <input type="hidden" name="id_denda" value="<?php echo e($k->id_denda); ?>">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="list_kategori">Tanggal</label>
                                        <input class="form-control" type="date" name="tgl" value="<?php echo e($k->tgl); ?>">
                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="list_kategori">Nama</label>
                                        <select class="form-control" name="nama" id="">
                                            <option value="<?php echo e($k->nama); ?>"><?php echo e($k->nama); ?></option>
                                            <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($s->nama); ?>"
                                                    <?php echo e($s->nama == $k->nm_karyawan ? 'selected' : ''); ?>>
                                                    <?php echo e($s->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="list_kategori">Alasan</label>
                                        <input class="form-control" type="text" name="alasan"
                                            value="<?php echo e($k->alasan); ?>">
                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="list_kategori">Nominal</label>
                                        <input class="form-control" type="number" name="nominal"
                                            value="<?php echo e($k->nominal); ?>">
                                    </div>
                                </div>


                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-costume" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-costume">Edit / Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/denda/denda.blade.php ENDPATH**/ ?>