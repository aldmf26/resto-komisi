
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper" style="min-height: 511px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container">
                <div class="row mb-2 justify-content-center">
                    <div class="col-sm-12">

                        <h4 style="color: rgb(120, 120, 120); font-weight: bold; --darkreader-inline-color:#837e75;"
                            data-darkreader-inline-color="">Add Koki</h4>


                    </div><!-- /.col -->

                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-6">
                        <div class="card">
                            <form action="<?php echo e(route('absenKoki')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="card-header">
                                    <label for="">Add Koki</label>
                                    <div class="form-group" data-select2-id="93">
                                        <select name="id_karyawan[]" class="select2 select2-hidden-accessible" multiple=""
                                            data-placeholder="Add Koki" style="width: 100%;" data-select2-id="7"
                                            tabindex="-1" aria-hidden="true">
                                            <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($d->id_karyawan); ?>"><?php echo e($d->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div><br>
                                    <button type="submit"
                                        class="btn btn-sm btn-block btn-primary float-right mt-2">Simpan</button>
                                </div>
                            </form>
                            <div id="tabelKoki">

                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

            $('.select2').select2()
            //Initialize Select2 Elements
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })

            var count_addKoki = 1;

        })
    </script>
    <script>
        $(document).ready(function(){
            // load halaman view
            var url = "<?php echo e(route('tabelKoki')); ?>"
            getUrl(url)
            function getUrl(url) {
                $("#tabelKoki").load(url, "data", function(response, status, request) {
                    this;
                });
            }
            // -------------------------
            $(document).on('click', '.hapusKoki', function(){
                var id_koki = $(this).attr('id_koki')
                var url = "<?php echo e(route('tabelKoki')); ?>"
                $.ajax({
                    type: "POST",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    url: "<?php echo e(route('delAbsKoki')); ?>?id_koki=" + id_koki,
                    success: function(response) {
                        getUrl(url)
                    }
                });
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1134130/resto_laravel/resources/views/addKoki/addKoki.blade.php ENDPATH**/ ?>