<?php

namespace App\Http\Controllers;

use App\Models\Karyawan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AccountingController extends Controller
{
   public function index(Request $request)
   {
    $id_user = Auth::user()->id;
    $id_menu = DB::table('tb_permission')->select('id_menu')->where('id_user',$id_user)
    ->where('id_menu', 21)->first();
    if(empty($id_menu)) {
        return back();
    } else {
        if(Auth::user()->jenis == 'adm') {
            $data = [
                'title' => 'Absen',
                'logout' => $request->session()->get('logout'),
            ];
    
            return view('accounting.accounting', $data);
        } else {
            return back();
        }
        
    }
   }
}
