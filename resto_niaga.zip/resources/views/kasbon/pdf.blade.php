<table border="1" cellpadding="8">
    <tr>
        <th>NO</th>
        <th>NAMA</th>
        <th>NOMINAL</th>
        <th>TANGGAL</th>
    </tr>
    @php
        $no = 1;
    @endphp
    @foreach ($kasbon as $k)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $k->nm_karyawan }}</td>
            <td>{{ $k->nominal }}</td>
            <td>{{ $k->tgl }}</td>
        </tr>
    @endforeach
</table>
