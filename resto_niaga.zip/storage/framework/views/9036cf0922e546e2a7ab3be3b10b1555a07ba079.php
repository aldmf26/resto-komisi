
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container">
                <div class="row mb-2 justify-content-center">
                    <div class="col-sm-12">

                    </div><!-- /.col -->

                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Data Gaji</h5>
                                <a href="" data-toggle="modal" data-target="#summary"
                                    class="btn btn-info btn-sm float-right"><i class="fas fa-download"></i> Summary</a>
                                <a href="" data-toggle="modal" data-target="#import"
                                    class="btn mr-2 btn-info btn-sm float-right"><i class="fas fa-file-import"></i>
                                    Import</a>
                                <a href="<?php echo e(route('gajiExport')); ?>" class="btn mr-2 btn-info btn-sm float-right"><i
                                        class="fas fa-file-export"></i>
                                    Export</a>
                            </div>
                            <?php echo $__env->make('flash.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="card-body">
                                <table class="table  " id="table">

                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>NAMA KARYAWAN</th>
                                            <th>POSISI</th>
                                            <th>TANGGAL MASUK</th>
                                            <th>RP M</th>
                                            <th>RP E</th>
                                            <th>RP SP</th>
                                            <th>BULANAN</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no = 1;
                                            
                                        ?>

                                        <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $totalKerja = new DateTime($k->tgl_masuk);
                                                $today = new DateTime();
                                                $tKerja = $today->diff($totalKerja);
                                            ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($k->nama); ?></td>
                                                <td><?php echo e($k->nm_posisi); ?></td>
                                                <td><?php echo e($k->tgl_masuk); ?> (<?php echo e($tKerja->y); ?> Tahun)</td>
                                                <td><?php echo e(number_format($k->rp_m, 0)); ?></td>
                                                <td><?php echo e(number_format($k->rp_e, 0)); ?></td>
                                                <td><?php echo e(number_format($k->rp_sp, 0)); ?></td>
                                                <td><?php echo e(number_format($k->g_bulanan, 0)); ?></td>
                                                <td style="white-space: nowrap;">
                                                    <a href="" data-toggle="modal"
                                                        data-target="#edit_data<?php echo e($k->id_karyawan); ?><?php echo e($k->id_gaji); ?>"
                                                        id_menu="1" class="btn edit_menu btn-new"
                                                        style="background-color: #F7F7F7;"><i style="color: #B0BEC5;"><i
                                                                class="fas fa-edit"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <style>
        .modal-lg-max1 {
            max-width: 1100px;
        }

    </style>
    
    <form action="" method="post" enctype="multipart/form-data">
        <div class="modal fade" role="dialog" id="import" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content ">
                    <div class="modal-header btn-costume">
                        <h5 class="modal-title text-light" id="exampleModalLabel">Edit Gaji</h5>
                        <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <label for="">Dari</label>
                                <input required class="form-control" type="file" name=" file">
                            </div>
                        </div>

                    </div>


                    <div class="modal-footer">

                    </div>
                </div>
            </div>
        </div>
    </form>
    
    <div class="modal fade" role="dialog" id="summary" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg-max1" role="document">
            <div class="modal-content ">
                <div class="modal-header btn-costume">
                    <h5 class="modal-title text-light" id="exampleModalLabel">Edit Gaji</h5>
                    <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <label for="">Dari</label>
                            <input required class="form-control" type="date"" name=" dari" id="dari">
                        </div>
                        <div class="col-lg-4">
                            <label for="">Sampai</label>
                            <input required class="form-control" type="date" name="sampai" id="sampai">
                        </div>
                        <div class="col-sm-1">
                            <label for="">Aksi</label>
                            <button id="submit" class="form-control btn btn-sm btn-info">View</button>
                        </div>
                    </div>

                    <div id="badan">

                    </div>

                </div>


                <div class="modal-footer">

                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('editGaji')); ?>" method="post">
            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <div class="modal fade" id="edit_data<?php echo e($s->id_karyawan); ?><?php echo e($s->id_gaji); ?>" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-md" role="document">
                    <div class="modal-content ">
                        <div class="modal-header btn-costume">
                            <h5 class="modal-title text-light" id="exampleModalLabel">Edit Gaji</h5>
                            <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <input type="hidden" name="id_gaji" value="<?php echo e($s->id_gaji); ?>">
                        <input type="hidden" name="id_karyawan" value="<?php echo e($s->id_karyawan); ?>">
                        <div class="modal-body">
                            <p><b>Nama : <?php echo e($s->nama); ?></b></p>
                            <?php
                            $totalKerja = new DateTime($s->tgl_masuk);
                            $today = new DateTime();
                            $tKerja = $today->diff($totalKerja);
                            ?>
                            <p><b>Lama Bekerja : <?php echo e($tKerja->y); ?> tahun</b></p>
                            <hr style="border: 1px solid black">
                            <div class="row">
                                <div class="col-lg-3">
                                    <label for="">Rp M</label>
                                    <input class="form-control" type="text" value="<?php echo e($s->rp_m); ?>" name="rp_m">
                                </div>
                                <div class="col-lg-3">
                                    <label for="">Rp E</label>
                                    <input class="form-control" type="text" value="<?php echo e($s->rp_e); ?>" name="rp_e">
                                </div>
                                <div class="col-lg-3">
                                    <label for="">Rp SP</label>
                                    <input class="form-control" type="text" value="<?php echo e($s->rp_sp); ?>" name="rp_sp">
                                </div>
                                <div class="col-lg-3">
                                    <label for="">Bulanan</label>
                                    <input class="form-control" type="text" value="<?php echo e($s->g_bulanan); ?>"
                                        name="g_bulanan">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-costume" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <style>
        .modal-lg-max {
            max-width: 900px;
        }

    </style>



    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $(document).on('click', '#submit', function() {
                var dari = $('#dari').val()
                var sampai = $('#sampai').val()
                if (dari == '' || sampai == '') {
                    alert('Isi dulu Tanggalnya')
                } else {

                    $('#ketDari').text(dari)
                    $('#ketSampai').text(sampai)
                    $('#badan').load("<?php echo e(route('tabelGaji')); ?>?dari=" + dari + "&sampai=" + sampai,
                        "data",
                        function(response, status,
                            request) {
                            this; // dom element
                            $('#tableSum').DataTable({

                                "bSort": true,
                                // "scrollX": true,
                                "paging": true,
                                "stateSave": true,
                                "scrollCollapse": true
                            });
                        });
                }
                // alert(`dari : ${dari} sampai : ${sampai}`)
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1134130/resto_laravel/resources/views/gaji/gaji.blade.php ENDPATH**/ ?>