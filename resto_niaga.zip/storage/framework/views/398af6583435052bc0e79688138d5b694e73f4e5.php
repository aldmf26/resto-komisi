<ul class="nav nav-pills mb-3 custom-scrollbar-css" id="pills-tab" role="tablist">
    <?php foreach ($distribusi as $d) : ?>
    <li class="nav-item">
        <?php if ($id == $d->id_distribusi) : ?>
        <?php if (empty($d->jumlah)) : ?>
        <a href="<?php echo e(route('meja', ['id' => $d->id_distribusi])); ?>" class="nav-link active badge-notif"><strong><?php echo e($d->nm_distribusi); ?></strong></a>
        <?php else : ?>
        <a href="<?php echo e(route('meja', ['id' => $d->id_distribusi])); ?>" data-badge="<?php echo e($d->jumlah); ?>"
            class="nav-link active badge-notif"><strong><?php echo e($d->nm_distribusi); ?></strong></a>
        <?php endif ?>

        <?php else : ?>
        <?php if (empty($d->jumlah)) : ?>
        <a href="<?php echo e(route('meja', ['id' => $d->id_distribusi])); ?>" class="nav-link badge-notif"><strong><?php echo e($d->nm_distribusi); ?></strong></a>
        <?php else : ?>
        <a href="<?php echo e(route('meja', ['id' => $d->id_distribusi])); ?>" data-badge="<?php echo e($d->jumlah); ?>"
            class="nav-link badge-notif"><strong><?php echo e($d->nm_distribusi); ?></strong></a>
        <?php endif ?>

        <?php endif ?>
    </li>
    <?php endforeach ?>
    <?php $__currentLoopData = $orderan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" id="jumlah1" value="<?php echo e($o->jml_order); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul><?php /**PATH C:\xampp\htdocs\resto_niaga\resources\views/meja/distribusi.blade.php ENDPATH**/ ?>