<table border="1" cellpadding="8">
    <tr>
        <th>NO</th>
        <th>NAMA</th>
        <th>NOMINAL</th>
        <th>TANGGAL</th>
    </tr>
    <?php
        $no = 1;
    ?>
    <?php $__currentLoopData = $kasbon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($k->nm_karyawan); ?></td>
            <td><?php echo e($k->nominal); ?></td>
            <td><?php echo e($k->tgl); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/kasbon/pdf.blade.php ENDPATH**/ ?>