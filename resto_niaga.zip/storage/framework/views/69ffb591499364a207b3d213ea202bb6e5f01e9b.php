<?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if($pesan = Session::get('sukses')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($pesan); ?></strong>
    </div>
<?php endif; ?>

<?php if($pesan = Session::get('error')): ?>
    <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($pesan); ?></strong>
    </div>
<?php endif; ?>

<?php if($pesan = Session::get('warning')): ?>
    <div class="alert alert-warning alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($pesan); ?></strong>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/flash/flash.blade.php ENDPATH**/ ?>