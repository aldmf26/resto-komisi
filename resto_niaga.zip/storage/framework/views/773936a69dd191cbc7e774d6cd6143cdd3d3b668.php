<table border="1" cellpadding="8">
    <tr>
        <th>NO</th>
        <th>TANGGAL</th>
        <th>NAMA</th>
        <th>ALASANA</th>
        <th>NOMINAL</th>
        <th>LOKASI</th>
    </tr>
    <?php
        $no = 1;
    ?>
    <?php $__currentLoopData = $denda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($k->tgl); ?></td>
            <td><?php echo e($k->nama); ?></td>
            <td><?php echo e($k->alasan); ?></td>
            <td><?php echo e($k->nominal); ?></td>
            <?php
                if ($k->id_lokasi == 1) {
                    $lokasi = 'TAKEMORI';
                } else {
                    $lokasi = 'SOONDOBU';
                }
            ?>
            <td><?php echo e($lokasi); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/denda/pdf.blade.php ENDPATH**/ ?>