<div class="subnavbar">
    <div class="subnavbar-inner">
        <div class="container text-center">
            <ul class="mainnav">
                <?php
                    $navbar = DB::table('tb_navbar')->get();
                    $sub_navbar = DB::table('tb_sub_navbar')->get();
                    $id_user = Auth::user()->id;
                    $cek = DB::table('tb_permission')
                        ->join('tb_sub_navbar', 'tb_permission.id_menu', '=', 'tb_sub_navbar.id_navbar')
                        ->join('tb_navbar', 'tb_sub_navbar.id_navbar', '=', 'tb_navbar.id_navbar')
                        ->where('tb_permission.id_user', $id_user)
                        ->where('tb_sub_navbar.jen', 1)
                        ->orderBy('urutan')
                        ->get();
                    $cekadm = DB::table('tb_permission')
                        ->join('tb_sub_navbar', 'tb_permission.id_menu', '=', 'tb_sub_navbar.id_navbar')
                        ->join('tb_navbar', 'tb_sub_navbar.id_navbar', '=', 'tb_navbar.id_navbar')
                        ->where('tb_permission.id_user', $id_user)
                        ->where('tb_sub_navbar.jen', 2)
                        ->orderBy('urutan')
                        ->get();
                ?>
                <?php if(Session::get('logout') == 'Adm'){ ?>
                <?php $__currentLoopData = $cekadm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($c->jenis == 'navbar'){ ?>
                    <li>
                        <a href="<?php echo e(route($c->rot)); ?>"><img
                                src="<?php echo e(asset('assets')); ?>/img_menu/<?php echo e($c->img); ?>"><span><?php echo e($c->sub_navbar); ?></span>
                        </a>
                    </li>
                    <?php } ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <img
                            src="<?php echo e(asset('assets')); ?>/img_menu/server.png"><span>Database</span> <b
                            class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <?php
                            $sub_navbar = DB::table('tb_permission')
                                ->join('tb_sub_navbar', 'tb_permission.id_menu', '=', 'tb_sub_navbar.id_sub_navbar')
                                ->where('id_navbar', 4)
                                ->where('tb_permission.id_user', $id_user)
                                ->get();
                        ?>
                        <?php $__currentLoopData = $sub_navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                if ($sn->id_sub_navbar == 11) {
                                    $get = '[]';
                                }
                            ?>
                            <li><a
                                    href="<?php echo e(route($sn->rot)); ?><?php echo e($sn->id_sub_navbar == 11 ? '?id_lokasi=1' : ''); ?><?php echo e($sn->id_sub_navbar == 12 ? '?id_lokasi=2' : ''); ?>"><?php echo e($sn->sub_navbar); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <?php }elseif(Session::get('logout') == 'Tkm' || Session::get('logout') == 'Sdb'){ ?>
                <?php $__currentLoopData = $cek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($c->jenis == 'navbar'){ ?>
                    <li>
                        <a href="<?php echo e(route($c->rot)); ?>"><img
                                src="<?php echo e(asset('assets')); ?>/img_menu/<?php echo e($c->img); ?>"><span><?php echo e($c->sub_navbar); ?></span>
                        </a>
                    </li>
                    <?php if($c->rot == 'laporan'){ ?>
                    <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="<?php echo e(asset('assets')); ?>/img_menu/order2.png"><span>Orderan</span> <b
                                class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <?php
                                $sub_navbar = DB::table('tb_permission')
                                    ->join('tb_sub_navbar', 'tb_permission.id_menu', '=', 'tb_sub_navbar.id_sub_navbar')
                                    ->where('id_navbar', 29)
                                    ->where('tb_permission.id_user', $id_user)
                                    ->get();
                            ?>
                            <?php $__currentLoopData = $sub_navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route($sn->rot)); ?>"><?php echo e($sn->sub_navbar); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <?php } ?>
                    <?php } ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="<?php echo e(asset('assets')); ?>/img_menu/notebook.png"><span>Catatan</span> <b
                            class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <?php
                            $sub_navbar = DB::table('tb_permission')
                                ->join('tb_sub_navbar', 'tb_permission.id_menu', '=', 'tb_sub_navbar.id_sub_navbar')
                                ->where('id_navbar', 3)
                                ->where('tb_permission.id_user', $id_user)
                                ->get();
                        ?>
                        <?php $__currentLoopData = $sub_navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route($sn->rot)); ?>"><?php echo e($sn->sub_navbar); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>


                <li class="dropdown"><a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> <img
                            src="https://upperclassindonesia.com/uploads/img_menu/warning-sign.png"><span>Peringatan</span>
                        <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <?php
                            $sub_navbar = DB::table('tb_permission')
                                ->join('tb_sub_navbar', 'tb_permission.id_menu', '=', 'tb_sub_navbar.id_sub_navbar')
                                ->where('id_navbar', 5)
                                ->where('tb_permission.id_user', $id_user)
                                ->get();
                        ?>
                        <?php $__currentLoopData = $sub_navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route($sn->rot)); ?>"><?php echo e($sn->sub_navbar); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>

                <?php } ?>
            </ul>
        </div>
        <!-- /container -->
    </div>
    <!-- /subnavbar-inner -->
</div>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\resto_niaga\resources\views/template/navbar.blade.php ENDPATH**/ ?>