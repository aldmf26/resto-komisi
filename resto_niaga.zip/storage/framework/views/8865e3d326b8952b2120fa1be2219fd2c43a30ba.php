<div id="permission">
    <h5>Administrator</h5>
    <?php $__currentLoopData = $navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $menu_id = DB::table('tb_permission')
                ->select('id_menu')
                ->where('id_user', 27)
                ->where('id_menu', $n->id_sub_navbar)
                ->where('lokasi', $jenis)
                ->first();
            $no = 1;
            //  dd($menu_id);
        ?>
        <div class="col-md-12">
            <input type="hidden" name="lokasi" value="<?php echo e($jenis); ?>">
            
            <div class="form-check ">
                <input class="form-check-input" <?php echo e($menu_id ? 'checked' : ''); ?> type="checkbox"
                    value="<?php echo e($n->id_sub_navbar); ?>" name="menu[]" id="check<?php echo e($no); ?>">
            </div>
            <label class="form-check-label ml-3 mb-3" for="check<?php echo e($no); ?>">
                <b><?php echo e($n->sub_navbar); ?></b>
            </label>
        </div>
        <?php
            $no++;
        ?>
        <?php
            if ($n->sub_navbar == 'Gaji') {
                break;
            }
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <h5>Database</h5>
    <hr>
    <?php $__currentLoopData = $database; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $menu_id = DB::table('tb_permission')
                ->select('id_menu')
                ->where('id_user', 27)
                ->where('id_menu', $n->id_sub_navbar)
                ->where('lokasi', $jenis)
                ->first();
            $no = 1;
            //  dd($menu_id);
        ?>
        <div class="col-md-12">
            <input type="hidden" name="lokasi" value="<?php echo e($jenis); ?>">
            
            <div class="form-check ">
                <input class="form-check-input" <?php echo e($menu_id ? 'checked' : ''); ?> type="checkbox"
                    value="<?php echo e($n->id_sub_navbar); ?>" name="menu[]" id="check<?php echo e($no); ?>">
            </div>
            <label class="form-check-label ml-3 mb-3" for="check<?php echo e($no); ?>">
                <b><?php echo e($n->sub_navbar); ?></b>
            </label>
        </div>
        <?php
            $no++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h5>Resto</h5>
    <?php $__currentLoopData = $resto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $menu_id = DB::table('tb_permission')
                ->select('id_menu')
                ->where('id_user', 27)
                ->where('id_menu', $n->id_sub_navbar)
                ->where('lokasi', $jenis)
                ->first();
            $no = 1;
            //  dd($menu_id);
        ?>
        <div class="col-md-12">
            <input type="hidden" name="lokasi" value="<?php echo e($jenis); ?>">
            
            <div class="form-check ">
                <input class="form-check-input" <?php echo e($menu_id ? 'checked' : ''); ?> type="checkbox"
                    value="<?php echo e($n->id_sub_navbar); ?>" name="menu[]" id="check<?php echo e($no); ?>">
            </div>
            <label class="form-check-label ml-3 mb-3" for="check<?php echo e($no); ?>">
                <b><?php echo e($n->sub_navbar); ?></b>
            </label>
        </div>
        <?php
            $no++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <h5>Catatan</h5>

    <?php $__currentLoopData = $catatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $menu_id = DB::table('tb_permission')
                ->select('id_menu')
                ->where('id_user', 27)
                ->where('id_menu', $n->id_sub_navbar)
                ->where('lokasi', $jenis)
                ->first();
            $no = 1;
            //  dd($menu_id);
        ?>
        <div class="col-md-12">
            <input type="hidden" name="lokasi" value="<?php echo e($jenis); ?>">
            
            <div class="form-check ">
                <input class="form-check-input" <?php echo e($menu_id ? 'checked' : ''); ?> type="checkbox"
                    value="<?php echo e($n->id_sub_navbar); ?>" name="menu[]" id="check<?php echo e($no); ?>">
            </div>
            <label class="form-check-label ml-3 mb-3" for="check<?php echo e($no); ?>">
                <b><?php echo e($n->sub_navbar); ?></b>
            </label>
        </div>
        <?php
            $no++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <h5>Peringatan</h5>
    <hr>
    <?php $__currentLoopData = $peringatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $menu_id = DB::table('tb_permission')
                ->select('id_menu')
                ->where('id_user', 27)
                ->where('id_menu', $n->id_sub_navbar)
                ->where('lokasi', $jenis)
                ->first();
            $no = 1;
            //  dd($menu_id);
        ?>
        <div class="col-md-12">
            <input type="hidden" name="lokasi" value="<?php echo e($jenis); ?>">
            
            <div class="form-check ">
                <input class="form-check-input" <?php echo e($menu_id ? 'checked' : ''); ?> type="checkbox"
                    value="<?php echo e($n->id_sub_navbar); ?>" name="menu[]" id="check<?php echo e($no); ?>">
            </div>
            <label class="form-check-label ml-3 mb-3" for="check<?php echo e($no); ?>">
                <b><?php echo e($n->sub_navbar); ?></b>
            </label>
        </div>
        <?php
            $no++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\Resto_laravel\resources\views/users/adminMenu.blade.php ENDPATH**/ ?>