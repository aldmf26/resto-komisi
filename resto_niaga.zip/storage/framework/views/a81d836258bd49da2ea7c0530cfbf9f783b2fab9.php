<style>
    th {
        position: sticky;
        top: 0;
        z-index: 998;
    }

    .scrl {
        overflow: auto;
    }

</style>
<div class="card">
    <input type="hidden" id="nopage" value="">
    <table class="table table-md table-striped table-bordered" width="100%">
        <thead class="table-success">
            <tr>
                <?php
                    $tgl = getdate();
                    
                    $bulan;
                    $tahun_2;
                    // $bulan = date('m');
                    // $tahun_2 = date('Y');
                    $tanggal = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun_2);
                    $total = $tanggal;
                ?>
                <th style="white-space: nowrap;position: sticky;
                left: 0;
                z-index: 999;">NAMA</th>
                <?php for($i = 1; $i <= $total; $i++): ?>
                    <th class="text-center"><?php echo e($i); ?></th>
                <?php endfor; ?>
                <th>M</th>
                <th>E</th>
                <th>SP</th>
                <th>OFF</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $no = 1;
                
            ?>
            
            <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $totalOff = 0;
                    $totalM = 0;
                    $totalE = 0;
                    $totalSP = 0;
                ?>
                <tr>
                    <td class="bg-dark" style="white-space: nowrap;position: sticky;
                    left: 0;
                    z-index: 999;">
                        <h5><?php echo e($d->nama); ?></h5>
                    </td>
                    <?php for($i = 1; $i <= $total; $i++): ?>
                        <?php
                            $data = DB::table('tb_absen')
                                ->select('tb_absen.*')
                                ->where('id_karyawan', '=', $d->id_karyawan)
                                ->whereDay('tgl', '=', $i)
                                ->whereMonth('tgl', '=', $bulan)
                                ->whereYear('tgl', '=', $tahun_2)
                                ->first();
                            
                        ?>
                        <?php if($data) { ?>
                        <td class="text-center m">
                            <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                            <?php if($data->status == 'M'): ?>
                                <div class="dropdown">
                                    <button class="btnHapus btn btn-block btn-success" id="dropdownMenuButton1"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        M
                                    </button>
                                    <ul class="dropdown-menu tutup" aria-labelledby="dropdownMenuButton1">
                                        <li>
                                            <a style="width:60px;" href="javascript:void(0)"
                                                class="btnUpdate btn text-center btn-warning mb-3" status="E"
                                                id_absen="<?php echo e($data->id_absen); ?>" tahun="<?php echo e($tahun_2); ?>"
                                                bulan="<?php echo e($bulan); ?>">E</a>
                                        </li>
                                        <li>
                                            <a style="width:60px;" class="btnUpdate btn text-center btn-primary"
                                                href="javascript:void(0)" status="SP" id_absen="<?php echo e($data->id_absen); ?>"
                                                tahun="<?php echo e($tahun_2); ?>" bulan="<?php echo e($bulan); ?>">SP</a>
                                        </li>
                                        <li>
                                            <a style="width:60px;" class="btnDelete btn text-center btn-info mt-3"
                                                href="javascript:void(0)" status="OFF"
                                                id_absen="<?php echo e($data->id_absen); ?>" tahun="<?php echo e($tahun_2); ?>"
                                                bulan="<?php echo e($bulan); ?>">OFF</a>
                                        </li>
                                    </ul>
                                </div>

                                <?php
                                    $totalM++;
                                ?>
                            <?php elseif($data->status == 'E'): ?>
                                <div class="dropdown">
                                    <button class="btnHapus btn btn-block btn-warning" id="dropdownMenuButton1"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        E
                                    </button>
                                    <ul class="dropdown-menu tutup" aria-labelledby="dropdownMenuButton1">
                                        <li><a style="width:60px;" class="btnUpdate btn text-center btn-success mb-3"
                                                href="javascript:void(0)" status="M" id_absen="<?php echo e($data->id_absen); ?>"
                                                tahun="<?php echo e($tahun_2); ?>" bulan="<?php echo e($bulan); ?>">M</a>
                                        </li>
                                        <li><a style="width:60px;" class="btnUpdate btn text-center btn-primary"
                                                href="javascript:void(0)" status="SP"
                                                id_absen="<?php echo e($data->id_absen); ?>" tahun="<?php echo e($tahun_2); ?>"
                                                bulan="<?php echo e($bulan); ?>">SP</a>
                                        </li>
                                        <li>
                                            <a style="width:60px;" class="btnDelete btn text-center btn-info mt-3"
                                                href="javascript:void(0)" status="OFF"
                                                id_absen="<?php echo e($data->id_absen); ?>" tahun="<?php echo e($tahun_2); ?>"
                                                bulan="<?php echo e($bulan); ?>">OFF</a>
                                        </li>
                                    </ul>
                                </div>
                                <?php
                                    $totalE++;
                                ?>
                            <?php elseif($data->status == 'SP'): ?>
                                <div class="dropdown">
                                    <button href="javascript:void(0)" class="btnHapus btn btn-block btn-primary"
                                        id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                        SP
                                    </button>
                                    <ul class="dropdown-menu tutup" aria-labelledby="dropdownMenuButton1">
                                        <li><a style="width:60px;" class="btnUpdate btn text-center btn-warning mb-3"
                                                href="javascript:void(0)" status="E" id_absen="<?php echo e($data->id_absen); ?>"
                                                tahun="<?php echo e($tahun_2); ?>" bulan="<?php echo e($bulan); ?>">E</a>
                                        </li>
                                        <li><a style="width:60px;" class="btnUpdate btn text-center btn-success"
                                                href="javascript:void(0)" status="M" id_absen="<?php echo e($data->id_absen); ?>"
                                                tahun="<?php echo e($tahun_2); ?>" bulan="<?php echo e($bulan); ?>">M</a>
                                        </li>
                                        <li>
                                            <a style="width:60px;" class="btnDelete btn text-center btn-info mt-3"
                                                href="javascript:void(0)" status="OFF"
                                                id_absen="<?php echo e($data->id_absen); ?>" tahun="<?php echo e($tahun_2); ?>"
                                                bulan="<?php echo e($bulan); ?>">OFF</a>
                                        </li>
                                    </ul>
                                </div>
                                <?php
                                    $totalSP++;
                                ?>
                        </td>
                    <?php else: ?>
                        <td class="bg-info m">
                            <a href="javascript:void(0)" class="btn btn-block  btn-info">
                                OFF
                            </a>
                        </td>
                        <?php
                            $totalOff++;
                        ?>
                    <?php endif; ?>
                    <?php }else { ?>
                    <td class="bg-info m">
                        <a href="javascript:void(0)" id="input<?php echo e($d->id_karyawan); ?>"
                            class="btnInput btn btn-block  btn-info" status="M" id_karyawan="<?php echo e($d->id_karyawan); ?>"
                            page="3" tahun="<?php echo e($tahun_2); ?>" bulan="<?php echo e($bulan); ?>"
                            tanggal="<?php echo e($tahun_2 . '-' . $bulan . '-' . $i); ?>">
                            OFF
                        </a>
                    </td>
                    <?php
                        $totalOff++;
                    ?>
                    <?php } ?>
            <?php endfor; ?>
            <td class="bg-light"><?php echo e($totalM); ?></td>
            <td class="bg-light"><?php echo e($totalE); ?></td>
            <td class="bg-light"><?php echo e($totalSP); ?></td>
            <td class="bg-light"><?php echo e($totalOff); ?></td>

            </tr>
            <?php if($d->id_karyawan == $d->id_karyawan): ?>
                <?php
                    continue;
                ?>
            <?php else: ?>
                <?php
                    break;
                ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
</div>
<?php /**PATH C:\xampp\htdocs\resto_niaga\resources\views/absen/tabelAbsens.blade.php ENDPATH**/ ?>